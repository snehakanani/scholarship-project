<?php 
// DB credentials.
define('DB_HOST', '127.0.0.1'); // Use the IP address instead of "localhost" for consistency.
define('DB_PORT', '3307'); // Specify the correct port.
define('DB_USER', 'root');
define('DB_PASS', ''); // Add password if applicable.
define('DB_NAME', 'scholarshipdb');

// Establish database connection.
try {
    $dbh = new PDO(
        "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME,
        DB_USER,
        DB_PASS,
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'")
    );
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
?>
